<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";

const username = ref("");
const password = ref("");
const errorMessage = ref("");
const router = useRouter();

const login = async () => {
  errorMessage.value = ""; // Очищаем ошибку перед отправкой
  try {
    const response = await fetch("http://localhost:5001/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: username.value, password: password.value }),
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.message || "Ошибка входа");
    }

    // Сохраняем токен и роль в localStorage
    localStorage.setItem("token", data.token);
    localStorage.setItem("role", data.role);

    alert("✅ Вход успешен!");
    router.push("/"); // Перенаправление на главную страницу
  } catch (error) {
    errorMessage.value = error.message;
  }
};
</script>

<template>
  <div class="login-container">
    <h1>Войти</h1>

    <form @submit.prevent="login" class="login-form">
      <input v-model="username" placeholder="Логин" required class="input-field"/>
      <input v-model="password" type="password" placeholder="Пароль" required class="input-field"/>
      <button type="submit" class="login-btn">Войти</button>
    </form>

    <p v-if="errorMessage" class="error">{{ errorMessage }}</p>
  </div>
</template>

<style scoped>
/* 🌸 Основной контейнер */
.login-container {
  max-width: 400px;
  margin: 50px auto;
  padding: 20px;
  background: linear-gradient(135deg, #ff69b4, #ff1493);
  border-radius: 12px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
  text-align: center;
  color: white;
}

/* 🏷 Заголовок */
h1 {
  margin-bottom: 15px;
}

/* 🔷 Форма */
.login-form {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

/* 🔲 Поля ввода */
.input-field {
  padding: 10px;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  width: 100%;
  outline: none;
}

/* 🔘 Кнопка */
.login-btn {
  background: white;
  color: #ff1493;
  font-size: 16px;
  font-weight: bold;
  padding: 10px;
  border-radius: 8px;
  border: none;
  cursor: pointer;
  transition: 0.3s;
}

.login-btn:hover {
  background: #ff1493;
  color: white;
  transform: scale(1.05);
}

/* 🚨 Ошибка */
.error {
  color: yellow;
  font-weight: bold;
  margin-top: 10px;
}
</style>