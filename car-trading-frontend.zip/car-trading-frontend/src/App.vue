<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";

// Данные пользователя
const token = ref(localStorage.getItem("token"));
const role = ref(localStorage.getItem("role"));
const router = useRouter();

// Выход из системы
const logout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("role");
  token.value = null;
  role.value = null;
  router.push("/login"); // Перенаправляем на страницу логина
};
</script>

<template>
  <div>
    <!-- 🌸 Навигация -->
    <nav class="navbar">
      <div class="nav-left">
        <router-link to="/" class="nav-link">🏠 Главная</router-link>
        <router-link v-if="role === 'admin'" to="/add" class="nav-link">➕ Добавить машину</router-link>
      </div>

      <div class="nav-right">
        <!-- Если пользователь НЕ авторизован, показываем "Войти" и "Регистрация" -->
        <template v-if="!token">
          <router-link to="/login" class="nav-link">🔑 Войти</router-link>
          <router-link to="/register" class="nav-link">📝 Регистрация</router-link>
        </template>

        <!-- Если авторизован – показываем только кнопку выхода -->
        <button v-else @click="logout" class="logout-btn">🚪 Выйти</button>
      </div>
    </nav>

    <!-- Контент -->
    <router-view />
  </div>
</template>

<style scoped>
/* 💖 Основной стиль навбара */
.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: linear-gradient(45deg, #ff69b4, #ff1493);
  padding: 12px 20px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  border-radius: 10px;
}

/* 📌 Контейнеры навигации */
.nav-left, .nav-right {
  display: flex;
  align-items: center;
}

/* 🎀 Ссылки в навбаре */
.nav-link {
  color: white;
  text-decoration: none;
  font-size: 16px;
  font-weight: bold;
  margin-right: 15px;
  padding: 8px 12px;
  border-radius: 20px;
  transition: background 0.3s, transform 0.2s;
}

.nav-link:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: scale(1.05);
}

/* 🚪 Кнопка выхода */
.logout-btn {
  background: white;
  color: #ff1493;
  font-weight: bold;
  padding: 8px 12px;
  border: 2px solid #ff69b4;
  border-radius: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.logout-btn:hover {
  background: #ff69b4;
  color: white;
  transform: scale(1.05);
}
</style>