<script setup>
import { ref, computed, onMounted } from "vue";
import { useRouter } from "vue-router";

const cars = ref([]);
const token = ref(localStorage.getItem("token"));
const role = ref(localStorage.getItem("role"));
const router = useRouter();

// Фильтры
const searchQuery = ref("");
const minPrice = ref("");
const maxPrice = ref("");

const isAdmin = computed(() => role.value === "admin");

// 📌 Загружаем список машин
const fetchCars = async () => {
  try {
    const response = await fetch("http://localhost:5001/api/cars");
    if (!response.ok) throw new Error("Ошибка загрузки машин");

    cars.value = await response.json();
  } catch (error) {
    console.error("Ошибка:", error);
  }
};

// 📌 Удаление машины
const deleteCar = async (id) => {
  if (!confirm("Вы уверены, что хотите удалить эту машину?")) return;
  try {
    const response = await fetch(`http://localhost:5001/api/cars/${id}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${token.value}` },
    });
    if (response.ok) {
      cars.value = cars.value.filter(car => car._id !== id);
    }
  } catch (error) {
    console.error("Ошибка удаления:", error);
  }
};

// 📌 Фильтр машин
const filteredCars = computed(() => {
  return cars.value.filter(car =>
      (!searchQuery.value || car.title.toLowerCase().includes(searchQuery.value.toLowerCase())) &&
      (!minPrice.value || car.price >= Number(minPrice.value)) &&
      (!maxPrice.value || car.price <= Number(maxPrice.value))
  );
});

onMounted(fetchCars);
</script>

<template>
  <div class="container">
    <h1 class="title">🌸 Список машин</h1>

    <!-- Фильтры -->
    <div class="filters">
      <input v-model="searchQuery" type="text" placeholder="🔍 Поиск по названию" />
      <input v-model="minPrice" type="number" placeholder="Мин. цена" />
      <input v-model="maxPrice" type="number" placeholder="Макс. цена" />
    </div>

    <router-link v-if="isAdmin" to="/add" class="add-btn">➕ Добавить машину</router-link>

    <!-- Карточки машин -->
    <div v-if="filteredCars.length" class="car-list">
      <div v-for="car in filteredCars" :key="car._id" class="car-card">
        <img v-if="car.imageUrl" :src="'http://localhost:5001' + car.imageUrl" alt="Фото машины" class="car-image">
        <div class="car-info">
          <h2>{{ car.title || "Название не указано" }}</h2>
          <p><strong>Цена:</strong> {{ car.price ? car.price + " ₸" : "Не указано" }}</p>
          <p><strong>Пробег:</strong> {{ car.specs?.mileage ? car.specs.mileage + " км" : "Не указано" }}</p>
          <p><strong>Объем двигателя:</strong> {{ car.specs?.engine_volume ? car.specs.engine_volume + " л" : "Не указано" }}</p>
          <p><strong>Коробка:</strong> {{ car.specs?.transmission || "Не указано" }}</p>
          <p><strong>Привод:</strong> {{ car.specs?.drive_type || "Не указано" }}</p>
          <p><strong>Цвет:</strong> {{ car.specs?.color || "Не указано" }}</p>

          <!-- Кнопки -->
          <div class="buttons">
            <router-link :to="'/car/' + car._id" class="details-btn">🔍 Подробнее</router-link>
            <router-link v-if="isAdmin" :to="'/edit/' + car._id" class="edit-btn">✏ Редактировать</router-link>
            <button v-if="isAdmin" @click="deleteCar(car._id)" class="delete-btn">❌ Удалить</button>
          </div>
        </div>
      </div>
    </div>

    <p v-else>Нет машин по вашему запросу.</p>
  </div>
</template>

<style scoped>
/* Основные стили */
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
  background-color: #ffe4e1; /* Светло-розовый фон */
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.title {
  text-align: center;
  font-size: 28px;
  margin-bottom: 20px;
  color: #d63384; /* Ярко-розовый */
}

/* Фильтры */
.filters {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
}

.filters input {
  padding: 8px;
  font-size: 14px;
  border: 1px solid #ff69b4;
  border-radius: 5px;
  background: #fff0f5;
}

/* Кнопка добавления */
.add-btn {
  display: block;
  text-align: center;
  background-color: #ff69b4;
  color: white;
  padding: 10px 15px;
  text-decoration: none;
  border-radius: 5px;
  font-weight: bold;
  margin-bottom: 15px;
  transition: 0.3s;
}

.add-btn:hover {
  background-color: #d63384;
}

/* Карточки машин */
.car-list {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  justify-content: center;
}

.car-card {

  width: 380px;
  border-radius: 10px;
  overflow: hidden;
  background: #fff;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s;
  align-items: center;
}

.car-card:hover {
  transform: scale(1.03);
}

.car-image {
  width: 100%;
  max-width: 500px; /* Ограничиваем максимальную ширину */
  height: 280px;
  object-fit: cover;
  border-bottom: 3px solid #ff69b4;
  border-radius: 10px;
}

.car-info {
  padding: 15px;
  font-size: 14px;
}

.car-info h2 {
  font-size: 18px;
  margin-bottom: 8px;
  color: #c71585;
}

/* Кнопки */
.buttons {
  display: flex;
  gap: 10px;
  margin-top: 10px;
}

.details-btn {
  background-color: #ff1493;
  color: white;
  padding: 8px;
  text-decoration: none;
  border-radius: 5px;
  font-weight: bold;
}

.edit-btn {
  background-color: #ff69b4;
  color: white;
  padding: 8px;
  text-decoration: none;
  border-radius: 5px;
  font-weight: bold;
}

.delete-btn {
  background-color: #dc143c;
  color: white;
  padding: 8px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  font-weight: bold;
}
</style>