<script setup>
import { ref } from "vue";
import { useRoute } from "vue-router";

const route = useRoute();
const carId = route.params.id;
const rating = ref(5);
const comment = ref("");
const token = localStorage.getItem("token");

// 📌 Функция отправки отзыва
const submitReview = async () => {
  if (!token) {
    alert("Вы должны быть авторизованы!");
    return;
  }

  try {
    const response = await fetch("http://localhost:5001/api/reviews", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({carId, rating: rating.value, comment: comment.value}),
    });

    if (response.ok) {
      alert("✅ Отзыв добавлен!");
      window.location.reload();
    } else {
      const error = await response.json();
      alert("❌ Ошибка: " + error.message);
    }
  } catch (error) {
    console.error("Ошибка запроса:", error);
    alert("❌ Ошибка при добавлении отзыва.");
  }
};
</script>

<template>
  <div v-if="token" class="review-form">
    <h3>Оставить отзыв</h3>
    <div class="rating">
      <label>Оценка: </label>
      <select v-model="rating">
        <option v-for="n in 5" :key="n" :value="n">{{ n }}★</option>
      </select>
    </div>
    <textarea v-model="comment" placeholder="Напишите ваш отзыв..." required></textarea>
    <button @click="submitReview">Отправить</button>
  </div>
  <p v-else>🔒 Войдите, чтобы оставить отзыв.</p>
</template>

<style scoped>
.review-form {
  background: #ffe4e1; /* Розовый фон */
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  max-width: 400px;
  margin: 20px auto;
  text-align: center;
}

h3 {
  color: #ff1493;
}

.rating {
  margin-bottom: 10px;
}

select {
  padding: 8px;
  font-size: 16px;
  border-radius: 5px;
  border: 2px solid #ff69b4;
}

textarea {
  width: 100%;
  height: 80px;
  padding: 10px;
  border: 2px solid #ff69b4;
  border-radius: 5px;
  resize: none;
}

button {
  background-color: #ff69b4;
  color: white;
  padding: 10px;
  border: none;
  cursor: pointer;
  font-size: 16px;
  border-radius: 5px;
  margin-top: 10px;
  transition: 0.3s;
}

button:hover {
  background-color: #ff1493;
}
</style>