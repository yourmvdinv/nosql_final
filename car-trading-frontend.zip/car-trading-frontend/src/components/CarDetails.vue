<script setup>
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";
import ReviewList from "./ReviewList.vue";
import ReviewForm from "./ReviewForm.vue";

const route = useRoute();
const carId = route.params.id;
const car = ref(null);

const fetchCarDetails = async () => {
  try {
    const response = await fetch(`http://localhost:5001/api/cars/${route.params.id}`);
    if (!response.ok) throw new Error("Ошибка загрузки данных");
    car.value = await response.json();
  } catch (error) {
    console.error("Ошибка загрузки машины:", error);
  }
};

onMounted(fetchCarDetails);
</script>

<template>
  <div class="container" v-if="car">
    <h1 class="title">🚗 {{ car.title }}</h1>

    <div class="car-details">
      <img v-if="car.imageUrl" :src="'http://localhost:5001' + car.imageUrl" class="car-image" />

      <div class="car-info">
        <p><strong>💰 Цена:</strong> {{ car.price }} ₸</p>
        <p><strong>🏁 Пробег:</strong> {{ car.specs?.mileage }} км</p>
        <p><strong>🔧 Объем двигателя:</strong> {{ car.specs?.engine_volume }} л</p>
        <p><strong>⚙ Коробка передач:</strong> {{ car.specs?.transmission }}</p>
        <p><strong>🚙 Привод:</strong> {{ car.specs?.drive_type }}</p>
        <p><strong>🎨 Цвет:</strong> {{ car.specs?.color }}</p>
      </div>
    </div>

    <!-- Секция отзывов -->
    <div class="reviews-section">
      <h2 class="reviews-title">⭐ Отзывы</h2>
      <ReviewList :carId="carId" />
      <ReviewForm :carId="carId" />
    </div>
  </div>
  <p v-else class="loading">⏳ Загрузка...</p>
</template>

<style scoped>
/* Основные стили */
.container {
  max-width: 900px;
  margin: 0 auto;
  padding: 20px;
  background-color: #ffe4e1; /* Светло-розовый */
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

/* Заголовок */
.title {
  text-align: center;
  font-size: 28px;
  margin-bottom: 20px;
  color: #d63384;
}

/* Карточка авто */
.car-details {
  display: flex;
  gap: 20px;
  background: white;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.car-image {
  width: 500px;
  border-radius: 10px;
  border: 3px solid #ff69b4;
}

.car-info p {
  font-size: 16px;
  margin-bottom: 5px;
}

/* Отзывы */
.reviews-section {
  margin-top: 30px;
  background: white;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.reviews-title {
  font-size: 22px;
  color: #c71585;
  margin-bottom: 15px;
}

/* Загрузка */
.loading {
  text-align: center;
  font-size: 18px;
  color: #ff1493;
}
</style>