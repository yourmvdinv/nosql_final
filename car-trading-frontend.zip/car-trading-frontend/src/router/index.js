import { createRouter, createWebHistory } from "vue-router";
import CarList from "../components/CarList.vue";
import AddCar from "../components/AddCar.vue";
import EditCar from "../components/EditCar.vue";
import CarDetails from "../components/CarDetails.vue";  // Добавляем компонент
import Login from "../views/Login.vue";
import Register from "../views/Register.vue";

const routes = [
    { path: "/", component: CarList },
    { path: "/add", component: AddCar },
    { path: "/edit/:id", component: EditCar },
    { path: "/car/:id", component: CarDetails },  // Новый маршрут
    { path: "/login", component: Login },
    { path: "/register", component: Register },
];

const router = createRouter({
    history: createWebHistory(),
    routes,
});

export default router;