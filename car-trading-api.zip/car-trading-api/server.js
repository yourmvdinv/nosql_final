require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");

const { authenticateToken, isAdmin } = require("./middlewares/auth");

const app = express();
app.use(cors());
app.use(express.json());

// 📌 Подключение к MongoDB
mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
    .then(() => console.log("✅ Connected to MongoDB"))
    .catch(err => console.error("❌ MongoDB connection error:", err));

// 📌 Модель пользователя
const UserSchema = new mongoose.Schema({
    username: { type: String, unique: true, required: true },
    password: { type: String, required: true },
    role: { type: String, default: "user" } // "admin" или "user"
});
const User = mongoose.model("User", UserSchema);

// 📌 Регистрация пользователя
app.post("/api/register", async (req, res) => {
    try {
        const { username, password, role } = req.body;

        if (!username || !password) {
            return res.status(400).json({ message: "Заполните все поля!" });
        }

        const existingUser = await User.findOne({ username });
        if (existingUser) {
            return res.status(400).json({ message: "Пользователь уже существует!" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({ username, password: hashedPassword, role });
        await user.save();
        res.json({ message: "✅ Пользователь зарегистрирован!" });
    } catch (err) {
        res.status(500).json({ message: "Ошибка сервера" });
    }
});

// 📌 Логин пользователя
// 📌 Логин пользователя (server.js)
app.post("/api/login", async (req, res) => {
    try {
        const { username, password } = req.body;

        const user = await User.findOne({ username });
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ message: "❌ Неверный логин или пароль!" });
        }

        // ✅ Включаем `username` в токен!
        const token = jwt.sign(
            { userId: user._id, username: user.username, role: user.role },
            "SECRET_KEY",
            { expiresIn: "1h" }
        );

        res.json({ token, role: user.role });
    } catch (err) {
        res.status(500).json({ message: "Ошибка сервера" });
    }
});

// 📌 Подключаем маршруты машин
const carRoutes = require("./routes/cars");
app.use("/api/cars", carRoutes); // 📌 Правильное подключение маршрутов

app.use("/uploads", express.static("uploads"));
const reviewRoutes = require("./routes/reviews");
app.use("/api/reviews", reviewRoutes);
// 📌 Запуск сервера
const PORT = process.env.PORT || 5001;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));