const jwt = require("jsonwebtoken");

// 📌 Проверка токена

// 📌 Проверка токена
const authenticateToken = (req, res, next) => {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) return res.status(401).json({ message: "Нет доступа (Токен отсутствует)" });

    jwt.verify(token, "SECRET_KEY", (err, user) => {
        if (err) return res.status(403).json({ message: "Недействительный токен" });

        req.user = user; // ✅ Теперь `req.user` содержит `username`
        console.log("📌 Декодированный токен:", req.user); // Проверяем данные в консоли

        next();
    });
};

module.exports = { authenticateToken };


// 📌 Проверка роли (Admin)
const isAdmin = (req, res, next) => {
    if (req.user.role !== "admin") {
        return res.status(403).json({ message: "Недостаточно прав (Требуется Admin)" });
    }
    next();
};

module.exports = { authenticateToken, isAdmin };