const mongoose = require("mongoose");

const CarSchema = new mongoose.Schema({
    title: { type: String, required: true, index: true }, // Индексируем название для быстрого поиска
    price: { type: Number, required: true, index: true }, // Индексируем цену для эффективных запросов
    specs: {
        mileage: { type: Number, index: true }, // Индекс для поиска по пробегу
        engine_volume: Number,
        transmission: String,
        drive_type: String,
        color: String,
    },
    imageUrl: String,
    reviews: [{ type: mongoose.Schema.Types.ObjectId, ref: "Review" }], // Связь с отзывами
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true }, // Индексируем, чтобы быстро находить машины конкретного пользователя
}, { timestamps: true });

// Создание индексов для ускорения поиска
CarSchema.index({ title: 1 });
CarSchema.index({ price: 1 });
CarSchema.index({ "specs.mileage": 1 });
CarSchema.index({ userId: 1 });

module.exports = mongoose.model("Car", CarSchema, "listings");