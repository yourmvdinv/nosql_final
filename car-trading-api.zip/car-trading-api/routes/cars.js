const express = require("express");
const Car = require("../models/Car");
const { authenticateToken, isAdmin } = require("../middlewares/auth");
const router = express.Router();
const multer = require("multer");

// Конфигурация Multer для загрузки файлов
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "uploads/");
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + "-" + file.originalname);
    }
});


const upload = multer({ storage: storage });
// 📌 Получить все машины (публичный доступ)
router.get("/", async (req, res) => {
    try {
        const cars = await Car.find();
        res.json(cars);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// 📌 Получить машину по ID (публичный доступ)
router.get("/:id", async (req, res) => {
    try {
        const car = await Car.findById(req.params.id).populate("reviews"); // 🔥 Теперь подтягивает отзывы
        if (!car) return res.status(404).json({ message: "Машина не найдена" });

        res.json(car);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});


// 📌 Добавление машины (Только администратор)
router.post("/", authenticateToken, isAdmin, upload.single("image"), async (req, res) => {
    try {
        const { title, price, specs } = req.body;

        // Проверка обязательных полей
        if (!title || !price || !specs) {
            return res.status(400).json({ message: "⚠ Все поля обязательны!" });
        }

        const parsedSpecs = JSON.parse(specs);

        console.log("🚗 Данные для сохранения:", req.body, parsedSpecs);

        // Создание нового автомобиля с userId (пользователь, добавивший объявление)
        const car = new Car({
            title,
            price,
            specs: parsedSpecs,
            imageUrl: req.file ? `/uploads/${req.file.filename}` : "",
            userId: req.user.userId, // 📌 Сохраняем ID пользователя
        });

        await car.save();
        res.status(201).json({ message: "✅ Машина успешно добавлена!", car });
    } catch (err) {
        res.status(400).json({ message: "❌ Ошибка сохранения: " + err.message });
    }
});


// 📌 Обновить машину (Только админ)
// 📌 Обновить машину (Только админ)
router.put("/:id", authenticateToken, isAdmin, upload.single("image"), async (req, res) => {
    try {
        const specs = req.body.specs ? JSON.parse(req.body.specs) : {};

        const updateData = {
            title: req.body.title,
            price: req.body.price,
            specs: {
                mileage: req.body.mileage,
                engine_volume: req.body.engine_volume,
                transmission: req.body.transmission,
                drive_type: req.body.drive_type,
                color: req.body.color,
            },
        };

        // Если загружено новое фото, обновляем URL изображения
        if (req.file) {
            updateData.imageUrl = `/uploads/${req.file.filename}`;
        }

        const updatedCar = await Car.findByIdAndUpdate(req.params.id, updateData, { new: true });
        if (!updatedCar) return res.status(404).json({ message: "❌ Машина не найдена" });

        res.json(updatedCar);
    } catch (err) {
        res.status(400).json({ message: "❌ Ошибка обновления: " + err.message });
    }
});

// 📌 Удалить машину (Только админ)
router.delete("/:id", authenticateToken, isAdmin, async (req, res) => {
    try {
        const car = await Car.findByIdAndDelete(req.params.id);
        if (!car) return res.status(404).json({ message: "Машина не найдена" });
        res.json({ message: "Машина успешно удалена" });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;