const express = require("express");
const Review = require("../models/Review");
const Car = require("../models/Car"); // 📌 Добавили импорт
const { authenticateToken } = require("../middlewares/auth");
const router = express.Router();

// 📌 Получить все отзывы для конкретной машины (с полными данными о машине)
router.get("/:carId", async (req, res) => {
    try {
        const reviews = await Review.find({ carId: req.params.carId })
            .populate("carId", "title price specs imageUrl") // 📌 Загружаем данные о машине
            .sort({ createdAt: -1 });

        res.json(reviews);
    } catch (err) {
        res.status(500).json({ message: "Ошибка загрузки отзывов: " + err.message });
    }
});

// 📌 Добавить отзыв (Только авторизованные пользователи)
router.post("/", authenticateToken, async (req, res) => {
    try {
        const { carId, rating, comment } = req.body;

        if (!carId || !rating || !comment) {
            return res.status(400).json({ message: "⚠ ID машины, рейтинг и комментарий обязательны!" });
        }

        const review = new Review({
            carId,
            userId: req.user.userId,
            username: req.user.username,
            rating,
            comment,
        });

        await review.save();

        // 📌 Добавляем отзыв в массив `reviews` внутри документа машины
        await Car.findByIdAndUpdate(carId, { $push: { reviews: review._id } });

        res.status(201).json(review);
    } catch (err) {
        res.status(400).json({ message: "❌ Ошибка при добавлении отзыва: " + err.message });
    }
});

module.exports = router;