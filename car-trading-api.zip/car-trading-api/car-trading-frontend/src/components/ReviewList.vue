<script setup>
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";

const route = useRoute();
const reviews = ref([]);

const fetchReviews = async () => {
  try {
    const response = await fetch(`http://localhost:5001/api/reviews/${route.params.id}`);
    reviews.value = await response.json();
    console.log("✅ Отзывы загружены:", reviews.value);
  } catch (error) {
    console.error("Ошибка загрузки отзывов:", error);
  }
};

onMounted(fetchReviews);
</script>

<template>
  <div class="reviews-container">
    <h3>Отзывы</h3>
    <p v-if="reviews.length === 0">🚗 Отзывов пока нет.</p>

    <div v-for="review in reviews" :key="review._id" class="review">
      <p class="review-user">👤 <strong>{{ review.username || "Аноним" }}</strong></p>
      <p class="review-rating">⭐ {{ review.rating }}</p>
      <p class="review-comment">{{ review.comment }}</p>
    </div>
  </div>
</template>

<style scoped>
.reviews-container {
  max-width: 500px;
  margin: 20px auto;
  padding: 20px;
  background: #ffe4e1; /* Светло-розовый фон */
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

h3 {
  color: #ff1493;
  text-align: center;
}

.review {
  background: white;
  padding: 15px;
  border-radius: 8px;
  margin: 10px 0;
  box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
}

.review-user {
  font-weight: bold;
  color: #ff1493;
}

.review-rating {
  font-size: 18px;
}

.review-comment {
  margin-top: 5px;
  font-style: italic;
}
</style>