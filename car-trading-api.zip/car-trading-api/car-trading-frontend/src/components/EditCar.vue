<script setup>
import {ref, onMounted} from "vue";
import {useRoute, useRouter} from "vue-router";

const route = useRoute();
const router = useRouter();
const carId = route.params.id;

// Данные формы
const title = ref("");
const price = ref("");
const mileage = ref("");
const engineVolume = ref("");
const transmission = ref("");
const driveType = ref("");
const color = ref("");
const imageFile = ref(null); // Файл нового фото
const existingImageUrl = ref("");

// Загружаем данные машины
const fetchCar = async () => {
  try {
    const response = await fetch(`http://localhost:5001/api/cars/${carId}`);
    const car = await response.json();

    // Заполняем форму
    title.value = car.title;
    price.value = car.price;
    mileage.value = car.specs.mileage;
    engineVolume.value = car.specs.engine_volume;
    transmission.value = car.specs.transmission;
    driveType.value = car.specs.drive_type;
    color.value = car.specs.color;
    existingImageUrl.value = car.imageUrl;
  } catch (error) {
    console.error("Ошибка загрузки машины:", error);
  }
};

// Обработка выбора нового фото
const handleFileChange = (event) => {
  imageFile.value = event.target.files[0];
};

// Отправляем обновленные данные
const updateCar = async () => {
  const formData = new FormData();
  formData.append("title", title.value);
  formData.append("price", price.value);
  formData.append("mileage", mileage.value);
  formData.append("engine_volume", engineVolume.value);
  formData.append("transmission", transmission.value);
  formData.append("drive_type", driveType.value);
  formData.append("color", color.value);
  if (imageFile.value) {
    formData.append("image", imageFile.value);
  }

  try {
    const response = await fetch(`http://localhost:5001/api/cars/${carId}`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`, // Добавляем токен
      },
      body: formData, // Отправляем как `multipart/form-data`
    });

    if (response.ok) {
      alert("✅ Машина обновлена!");
      router.push("/"); // Возвращаемся на главную страницу
    } else {
      const errorText = await response.text();
      alert(`❌ Ошибка при обновлении машины: ${errorText}`);
    }
  } catch (error) {
    console.error("❌ Ошибка запроса:", error);
  }
};

onMounted(fetchCar);
</script>

<template>
  <div class="edit-container">
    <h1>Редактировать машину</h1>
    <form @submit.prevent="updateCar" class="edit-form">
      <label>Название: <input v-model="title" type="text" required/></label>
      <label>Цена: <input v-model="price" type="number" required/></label>
      <label>Пробег: <input v-model="mileage" type="number" required/></label>
      <label>Объем двигателя: <input v-model="engineVolume" type="number" step="0.1" required/></label>
      <label>Коробка передач:
        <select v-model="transmission">
          <option>Автомат</option>
          <option>Механика</option>
        </select>
      </label>
      <label>Привод:
        <select v-model="driveType">
          <option>Передний</option>
          <option>Задний</option>
          <option>Полный</option>
        </select>
      </label>
      <label>Цвет: <input v-model="color" type="text" required/></label>

      <!-- Отображение текущего фото -->
      <div v-if="existingImageUrl" class="image-container">
        <p>Текущее фото:</p>
        <img :src="'http://localhost:5001' + existingImageUrl" class="car-image">
      </div>

      <!-- Поле для загрузки нового фото -->
      <label>Новое фото:
        <input type="file" @change="handleFileChange" accept="image/*"/>
      </label>

      <button type="submit" class="save-btn">Сохранить</button>
    </form>
    <router-link to="/" class="back-btn">⬅ Назад</router-link>
  </div>
</template>

<style scoped>
/* 🌸 Контейнер формы */
.edit-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  background: #ffe4e1; /* Розовый фон */
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
  max-width: 500px;
  margin: 50px auto;
}

/* 🌸 Заголовок */
h1 {
  color: #ff1493;
  font-size: 24px;
  text-align: center;
  margin-bottom: 20px;
}

/* 🌸 Форма */
.edit-form {
  display: flex;
  flex-direction: column;
  gap: 10px;
  width: 100%;
}

/* 🌸 Поля формы */
input, select {
  width: 100%;
  padding: 8px;
  font-size: 14px;
  border: 2px solid #ff69b4;
  border-radius: 5px;
  outline: none;
}

/* 🌸 Кнопка сохранения */
.save-btn {
  background-color: #ff69b4;
  color: white;
  padding: 10px;
  border: none;
  cursor: pointer;
  font-size: 16px;
  border-radius: 5px;
  transition: 0.3s;
}

.save-btn:hover {
  background-color: #ff1493;
}

/* 🌸 Назад */
.back-btn {
  display: block;
  text-align: center;
  margin-top: 15px;
  color: #ff1493;
  font-weight: bold;
  text-decoration: none;
}

/* 🌸 Фото машины */
.image-container {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.car-image {
  width: 100%;
  max-width: 300px;
  height: 200px;
  object-fit: cover;
  border-radius: 10px;
  border: 3px solid #ff69b4;
  margin-top: 10px;
}
</style>